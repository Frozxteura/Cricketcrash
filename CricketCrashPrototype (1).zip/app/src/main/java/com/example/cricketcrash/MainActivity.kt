
package com.example.cricketcrash

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CricketCrashGame()
        }
    }
}

@Composable
fun CricketCrashGame() {
    var balance by remember { mutableStateOf(100.0) }
    var betAmount by remember { mutableStateOf(10.0) }
    var multiplier by remember { mutableStateOf(1.0) }
    var gameRunning by remember { mutableStateOf(false) }
    var crashed by remember { mutableStateOf(false) }

    LaunchedEffect(gameRunning) {
        if (gameRunning) {
            multiplier = 1.0
            crashed = false
            while (!crashed) {
                delay(500)
                multiplier += 0.1
                if (Random.nextDouble() < 0.05 * multiplier) {
                    crashed = true
                    gameRunning = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101010))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Balance: ₹${"%.2f".format(balance)}", color = Color.White, fontSize = 24.sp)

        if (gameRunning) {
            Text("Multiplier: ${"%.2f".format(multiplier)}x", color = Color.Yellow, fontSize = 36.sp)
        } else if (crashed) {
            Text("Crashed at ${"%.2f".format(multiplier)}x!", color = Color.Red, fontSize = 30.sp)
        }

        OutlinedTextField(
            value = betAmount.toString(),
            onValueChange = { betAmount = it.toDoubleOrNull() ?: 10.0 },
            label = { Text("Bet Amount") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (balance >= betAmount && !gameRunning) {
                    balance -= betAmount
                    gameRunning = true
                }
            },
            enabled = !gameRunning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("BET ₹${betAmount.toInt()}")
        }

        if (!gameRunning && crashed) {
            Button(
                onClick = {
                    // Win if multiplier > 2x
                    if (multiplier >= 2.0) {
                        balance += betAmount * multiplier
                    }
                    crashed = false
                    multiplier = 1.0
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Collect Winnings")
            }
        }
    }
}
